import axios from './axios'

export function fetchUsers(params) {
  return axios({
    url: '/topics',
    method: 'GET',
    params
  })
}
