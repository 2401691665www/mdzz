import React from 'react'
import './assets/css/app.scss'
import Test from './components/test'
export default class App extends React.Component {
  render() {
    return (
      <div className="App">
        <h1>Hellow React</h1>
        <Test/>
      </div>
    )
  }
}


