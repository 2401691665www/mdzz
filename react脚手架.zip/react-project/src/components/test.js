import React from 'react'

export default class Test extends React.Component{
    constructor(props) {
        super(props)
        this.state = {
            msg: 799,
        }
        var a = 1
        console.log(a)
    }

    render () {
        return(
            <div>
               <h2>测试react</h2> 
            </div>
        )
    }
}

